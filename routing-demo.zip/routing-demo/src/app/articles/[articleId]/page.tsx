"use client"
import Link from "next/link"
import { use } from "react"
type paramsProps = {
    params: Promise<{ articleId: string}>,
    searchParams: Promise<{ lang?: "en" | "es" | "fr"}>
}
export default  function NewsArticle({ params, searchParams}: paramsProps) {
    const { articleId } =  use(params)
    const { lang = "en" } =  use(searchParams);
   // When used in a Server Component, use():
   // unwraps the resolved value from a promise.
   // waits for the promise to resolve before rendering the component.
   // allows you to avoid writing async functions or using await.
   // so async await for server components and use for client components
    // we are assigning a value when destructuring because lang? is optional in type paramsProps
    // you can await and access params and searchParams in the news article component because it is a server component, if it was a client component, i will get an error since they do not support async/await

  return <div>
    <h1>News article {articleId}</h1>
    <p>Reading in {lang}</p>
    <div>
        <Link href={`/articles/${articleId}?lang=en`}>English</Link>
        <Link href={`/articles/${articleId}?lang=es`}>Spanish</Link>
        <Link href={`/articles/${articleId}?lang=fr`}>French</Link>
    </div>
  </div>
}
