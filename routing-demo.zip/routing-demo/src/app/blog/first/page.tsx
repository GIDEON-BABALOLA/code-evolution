export default function FirstBlog() {
  return (
    <div>My First Blog Page</div>
  )
}
