export const metadata = {
  title: "About Codeevolution"
}
export default function About() {
  return (
    <div>About page</div>
  )
}
