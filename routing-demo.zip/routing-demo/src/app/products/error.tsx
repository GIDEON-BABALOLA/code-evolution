"use client"
import { useRouter } from "next/navigation"
import { startTransition } from "react"
// error boundary must be client component
// What makes error so powerful
// - It automatically wraps route segments and their nested childern in a React Error Boundary
// - You can create custom error UIs for specific segments using the file-system hierarchy
// - It isolates errors to affected segments while keeping the rest of your app functional
// - It enables you to attempt to recover from an error without requiring a full page reload
// -  the retry function will attempt to re render the client
// - use starttrnasition and userouter to attempt server side recovery
// - An error.tsx file handles errors not just for its own folder, but for all the nested child segments below it too
export default function ErrorBoundary({ error, reset }: {error: Error, reset: () => void}){
    const router = useRouter();
    const reload = () => {
        startTransition(() => {
            router.refresh();
            reset();
        })
    }
    return (
    <div>
        <p>{error.message}</p>
        <button onClick={() => reload()}>Try again</button>
    </div>
)
}
