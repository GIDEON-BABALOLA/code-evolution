import { Card } from "@/components/card"
export default function RevenueMetrics() {
  return (
    <Card>Revenue Metrics</Card>
  )
}
