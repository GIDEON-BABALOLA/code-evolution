// fallback for users slot
import { Card } from "@/components/card"
export default function UsersAnalytics() {
  return (
    <Card>User Analytics default content</Card>
  )
}
