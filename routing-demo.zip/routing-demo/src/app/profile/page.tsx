
import { Metadata } from "next"
export const metadata: Metadata = {
  title: "Profile"
}
export default function Profile() {
  return (
    <div>Profile page</div>
  )
}
