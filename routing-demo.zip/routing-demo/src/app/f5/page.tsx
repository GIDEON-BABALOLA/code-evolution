export default function F5() {
  return (
    <h1> F5 page</h1>
  )
}
