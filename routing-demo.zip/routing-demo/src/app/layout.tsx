// Configuring metada
// Metadata rules
// - Both layout.tsx and page.tsx can export metadata. Layout metadata applies to all its pages, while page metadata is specific to that page
// - Metadata follows a top-down order, starting from the root level
// - When metadata exists in multiple places along a route, they merge together, with page metadata overriding layout metadata for matching properties
// - when you need more control over the title in metadata, you can define it as an object
// - Also layout does not support searchParams, it only supports params
import { Metadata } from 'next'
import { ErrorWrappper } from './error-wrapper'
export const metadata: Metadata = {
  title: {
    default: "Next.js Tutorial - Codevolution", // any child route that do not specify their own title
    template: "%s | Codevolution"
    // absolute: "", Absolute is used to break away from the default template in the app layout file
  },
  description: 'My Next.js App',
} 

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head />
      <body>
         <header
          style={{
            backgroundColor: "lightblue",
            padding: "1rem",
          }}
        >
          <p>Header</p>
        </header>
        <ErrorWrappper>{children}</ErrorWrappper>
        {/* {children} */}
            <footer
          style={{
            backgroundColor: "ghostwhite",
            padding: "1rem",
          }}
        >
          <p>Footer</p>
                </footer>
        </body>
    </html>
  )
}
