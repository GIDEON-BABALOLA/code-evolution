
export default function F3() {
      return (
    <h1>F3 page</h1>
  )
}
