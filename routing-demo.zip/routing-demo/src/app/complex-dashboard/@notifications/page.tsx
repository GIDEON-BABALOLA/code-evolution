import React from 'react'
import Link from 'next/link'
import { Card } from '@/components/card'
export default function Notifications() {
  return (

    <Card>
      <div className='flex flex-col'>
      <div>
Notifications initials
      </div>
      <div>
      <Link href={"/complex-dashboard/archived"}>Archived</Link>
      </div>
       </div>
      </Card>
  )
}
