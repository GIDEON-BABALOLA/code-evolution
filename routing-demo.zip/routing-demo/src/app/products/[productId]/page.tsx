import { notFound } from "next/navigation";
import { Metadata } from "next";
type paramsProps = {
    params: Promise<{ productId: string}>
}
// one important point to be mentioned is that is that you can't use both a metadata object and metadata fuction in the same route segment.
// Correct — metadata can only be generated on the server. If you mark your component with "use client", metadata functions will not run.
export const generateMetadata = async ( { params }: paramsProps): Promise<Metadata> => {
const id = (await params).productId;
// simulating an api request that will resolve in 100 millisecond
const title = await new Promise((resolve) => {
  setTimeout(() => {
    resolve(`iPhone ${id}`)
  }, 100);
})
return {
  title: `Product ${title}`
}
}
export default async function ProductDetails({ params }: paramsProps ) {
const productId = (await params).productId;
if(parseInt(productId) >  1000){
notFound()
}
  return (
    <h1>Details about product {productId}</h1>
  )
}
