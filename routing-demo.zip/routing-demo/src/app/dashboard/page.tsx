//page.tsx only supports a default exported component, file collation means that i can put multiple files in a folder and as far as it is not page.tsx, they would not be publicly accessed
export default function Dashboard() {
  return (
    <div>Dashboard</div>
  )
}
