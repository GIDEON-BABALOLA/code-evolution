export default function ComplexDashboardPage() {
  return (
    <h1>Complex Dashboard</h1>
  )
}
