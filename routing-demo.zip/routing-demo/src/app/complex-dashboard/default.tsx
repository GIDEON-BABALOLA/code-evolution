// Fallback for children slot
export default function ComplexDashboardPage() {
  return (
    <h1>Complex Dashboard default content</h1>
  )
}
