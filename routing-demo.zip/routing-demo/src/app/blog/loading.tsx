// Benefits of loading.tsx
// 1. It gives users immediate feedback when they navigate somewhere new
// This makes your app feel snappy and responsive, and users know their click actually did something.
// 2. Next.js keeps shared layouts interactive while new content loads
// users can still use things like navigation menus or sidebars even if the main content isn't ready yet
export default function Loading() {
  return (
    <div>Loading...</div>
  )
}
