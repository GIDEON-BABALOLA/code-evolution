export default function InterceptedF5() {
  return (
    <h1> (...) Intercepted F5 Page</h1>
  )
}
