import { redirect } from "next/navigation";
type paramsProps = {
    params: Promise<{ productId: string; reviewId: string}>
}
// function getRandomInt(count: number){
//   return Math.floor(Math.random() * count );
// }
export default async function ProductReview({ params }: paramsProps) {
  // const random = getRandomInt(2) 
  // return 0 or 1
  // we are trying to simulate an error here
  // if(random == 1){
  //   throw new Error("Error loading review")
  // }
    const { productId, reviewId } = (await params)
    if(parseInt(reviewId) > 1000){
     //  notFound(), notfound is imported from next/navigation; 
      redirect("/products")
      //creating specific notfound pages in different sections of your app
    }
  return (
   <h1>Review {reviewId} for product {productId}</h1>
  )
}
