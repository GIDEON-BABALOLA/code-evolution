import Link from "next/link"
export default function Home() {
  return (
 <>
   <h1>Welcome home!</h1>
   <Link href="/blog">Blog</Link>
   <Link href="/products">Products</Link>
   <Link href={"/articles/breaking-news-123?lang=en"}>Read in English</Link>
      <Link href={"/articles/breaking-news-123?lang=fr"}>Read in French</Link>
   </>
  )
}

// Private folders
// A way to tell Next.js, "Hey, this folder is just for internal stuff - don't include it in the routing system."
//The folder and all its subfolders are excluded from routing
//Add an underscore at the start of the folder name

// Route Groups
//Lets us logically organize our routes and project fils without impacting the URL structure
// Let's implement authentication toutes

// Params and searchParams
// For a given URL
// params is a promise that resolves to an object containing the dynamic route parameters (like id)
// searchParams is a promise that resolves to an object containing the query parameters (like filters and sorting)

// Templates
// Templates are similar to layouts in that they are also UI shared between multiple pages in your app
// Whenever a user navigates between routes sharing a template, you get a completely fresh start
// - a new template component instance is mounted
// - DOM elements are recreated
// - state is cleared
// - effects are re-syncronized

// Special files
// page.tsx
// layout.tsx
// template.tsx
// not-found.tsx
// loading.tsx
// error.tsx
// global-error.tsx

// Hanlding errors in layouts
// The error boundary won't catch errors thrown in layout.tsx within the same segment of how the component hierarchy.
// The layout actually sits above the error boundary in the component tree
// also error.tsx won't handle errors from layout in the same segment
// you will then have to move the error up one route or folder

// Handling global errors
// If an error boundary can't catch errors in the layout.tsx file from the same segment, what about errors in the root layout?
// It doesn't have a parent segment - how do we handle those errors
// Next.js provides a special file called global-error.tsx that goes in your root app directory
// global-error.tsx error boundary does not work because the global error boundary only works in production mode but in development mode we see the default nodeJs overlay
//

// Parallel Routes
// - what they are
// - how to set them up
// - why they're super useful when building complex user interfaces

// What they are
// - Parallel routing is an advanced routing mechanism that lets us render multiple pages simultaneously within the sam layout

// How to se them up
// - Parallel routes in Next.js are defined using a feature known as "slots"
// - slots help organize content in a modular way
// - To create a slot, we use the @folder naming convention
// Each defined slot automatically becomes a prop in its corresponding "layout.tsx" file

// Note that slots are not route segments and don't affect your url structure, also the children prop is parallel routing (e.g complex dashboard) is actually an implicit slot that does not need it's own folder, sp complex-dashboard/page.tsx is just like complex-dashboard/@children/page.tsx

// use cases for parralel-routing
// Dashboards with multiple sections
// split-view interfaces
// Multi-pane layouts
// - Complex admin interfaces

// benefits of  parralel-routing
// Parallel routes are great for splitting a layout into manageable slots(expecially) when different teams work on different parts)
// Independed route handling
// subnavigation

// Independent route handling
// Each slot in your layout, such as users, revenue, and notifications, can handle its own loading and error states
// This granular control is particularly useful in scenarios where different sections of the page load at varying speeds or encounter unique errors

// subnavigation
// Each slot can essentially function as a mini-application, complete with its own navigation and state management
// Users can interact with each section separately, applying filters, sorting sata, or navigating through pages without affecting each other parts

// Unmatched routes
// Next js handle unmatched slots differenctly depending on how you navigate
// Navigate=ing from the UI
// When navigating throuh the UI(like clicking links), Next.js 
// keeps showing whatever was in the unmatched slots before
// Page reload
// Next.js looks for a "default.txt" file in each unmatched slot
// This file is critical as it serves as a fallback to render content when the framework cannot retrieve a slot's 
// active state from the current URL, Without it you will get 404

// Conditional routes
// Imagine you want to show different content based on whether a user is logged in or not
// You might want to display a dashboard for authenticated users but show a login page for those who aren't
// Conditional routes allow us to achieve this while maintaining completely seperate code on the same URL

// The app router in nextJS introduced to advanced routing patterns
// Parallel routes
// Intercepting routes

// Intercepting Routes
// Intercepting routes is an advanced routing mechanism that
// allows you to load a route from another part of your
// application within the current layout
// It is particularly useful when you want to display new content
// while keeping your user in the same context

// Examples
// Consider a login flow

// Intercepting route conventions
// To create the target folder for the src folder in an
// intercepting route, you need to name the folder (.)foldername
// (.) to match segments on the same level
// (..) to match segments one level above
// (..)(..) to match segments two levels above
// (...) to match segments from the root app directory

// Parallel Intercepting Route
// 