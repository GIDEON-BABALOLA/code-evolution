
import { Metadata } from 'next'
export const metadata: Metadata = {
  title: "Articles",
} 
type paramsProps = {
    children: React.ReactNode
    params: Promise<{ articleId: string }>,
    // searchParams: Promise<{ lang?: "en" | "es" | "fr"}>
}
export default async function RootLayout({
  children,
  params,
  // searchParams
}: paramsProps) {
    const { articleId } = await params
    // const  { lang = "en" } = await searchParams
    // so now you can see that I am unable to access searchParams in layout
  return (
    <html lang="en">
      <head />
      <body>
         <header
          style={{
            backgroundColor: "lightblue",
            padding: "1rem",
          }}
        >
          <p>Header {articleId}</p>

        </header>
        {children}
            <footer
          style={{
            backgroundColor: "ghostwhite",
            padding: "1rem",
          }}
        >
          <p>Footer</p>
                </footer>
        </body>
    </html>
  )
}
