"use client" // useRouter only works in client components
// This example is for navigating programmatically
import { useRouter } from "next/navigation";
export default function OrderProduct() {
    const router = useRouter();
    const handleClick = () => {
        console.log("Placing your order");
        router.push("/")
        // router.replace("")
        // router.back(""), to go back in history
        // router.forward(""), to move forward in history
    }
  return (
   <>
   <h1>Order product</h1>
   <button onClick={handleClick}>Place order</button>
   </>
  )
}
