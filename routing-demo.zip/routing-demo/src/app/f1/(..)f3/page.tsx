export default function InterceptedF3() {
  return (
    <h1>(..) Intercepted F3 page</h1>
  )
}
