export default function ReviewList() {
  return (
   <>
   <h1>Review List</h1>
    <h1>Review 1</h1>
    <h1>Review 2</h1>
    <h1>Review 3</h1>
   </>
  )
}
