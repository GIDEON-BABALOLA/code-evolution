import { Card } from "@/components/card"
export default function UsersAnalytics() {
  return (
    <Card>User Analytics</Card>
  )
}
