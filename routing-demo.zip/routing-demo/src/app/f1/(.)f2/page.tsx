export default function InterceptedF2() {
  return (
    <h1>(.) Intercepted F2 page</h1>
  )
}
