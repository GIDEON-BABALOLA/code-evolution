import { Card } from "@/components/card"
export default function LoginSlot() {
  return (
    <Card>Please login to continue</Card>
  )
}
