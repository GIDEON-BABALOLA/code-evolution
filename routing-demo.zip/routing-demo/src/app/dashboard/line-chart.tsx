export default function LineChart() {
  return (
    <div>Line Chart</div>
  )
}
