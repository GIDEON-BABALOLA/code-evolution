export default function InterceptedF4() {
  return (
    <h1>(..)(..) Intercepted F4 page</h1>
  )
}
