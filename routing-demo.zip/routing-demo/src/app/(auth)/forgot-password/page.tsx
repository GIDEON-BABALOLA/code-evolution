export default function ForgotPassword() {
  return (
    <h1>ForgotPassword</h1>
  )
}
