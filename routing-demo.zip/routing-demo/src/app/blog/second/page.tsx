export default function SecondBlog() {
  return (
    <div>My Second Blog</div>
  )
}
