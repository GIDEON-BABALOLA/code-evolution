import React from 'react'
import Link from 'next/link'
import { Card } from '@/components/card'
export default function ArchivedNotifications() {
  return (

    <Card>
      <div className='flex flex-col'>
      <div>
Archived Notifications
      </div>
      <div>
      <Link href={"/complex-dashboard"}>Default</Link>
      </div>
        </div>
      </Card>
  )
}
