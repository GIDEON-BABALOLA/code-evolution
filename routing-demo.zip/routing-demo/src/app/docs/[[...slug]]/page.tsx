//before it was [...slug] but now it is [[...slug]] so that when i go to localhost:3000/docs i won't see a 404 page
// before self if i go to localhost:3000/docs/feature1/concept1 and it does not exist( meaning i did not catch it with if/else)
//then just docs home page will show up ( what was in my page.tsx in my [...docs] root folder)
type paramsProps = {
    params: Promise<{ slug: string[]}>
}
export default async function Docs({ params
}: paramsProps) {
        const { slug } = (await params)
        if(slug?.length === 3){
       return (
                <h1>
                    Viewing docs for feature {slug[0]} and concept {slug[1]} and example {slug[2]}
                </h1>
            )
        }
        else if(slug?.length === 2){
            return (
                <h1>
                    Viewing docs for feature {slug[0]} and concept {slug[1]}
                </h1>
            )
        }else if(slug?.length === 1){
            return (
                <h1>
                    Viewing docs for feature {slug[0]}
                </h1>
            )
        }
  return (
    <h1>Docs home page</h1>
  )
}
