import { Metadata } from "next"

export const metadata: Metadata = {
  title: {
    absolute: "Blog" // Absolute is used to break away from the default template in the app layout file
  }
}
export default async function Blog() {
  //To simulate a delay so that I can see my loading ui
  await new Promise((resolve) => {
    setTimeout(() => {
      resolve("intentional delay")
    }, 2000);
  })
  return (
    <div>My  Blog Page</div>
  )
}
