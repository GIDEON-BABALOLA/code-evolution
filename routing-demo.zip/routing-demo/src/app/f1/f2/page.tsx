import Link from "next/link"
export default function F2() {
  return (
    <h1>F2 Page
      <Link href={"/f4"}>F4</Link>
    </h1>
  )
}
